Open the .pde file and click 'Run' to display the image.

Press '1' to show the grayscale filter.
Press '2' to show the contrast filter.
	- Here, you can:
		Press 'q' or 'w' to change between two contrast thresholds
		Press 'a' or 's' to change between two contrast values
Press '3' to show the gaussian blue filter.
	- Here, you can:
		Press 'q' or 'w' to change between two different types of convolutions (sharpen or guassian blur)
		Press 'a' or 's' to change between two different types of edge calculations
Press '4' to show the edge detection filter.
	- This filter was not fully implemented.