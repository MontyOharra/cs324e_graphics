1. Install the Minim library to allow the sound of birds to be loaded and played. (Sketch > Import Library... > Manage Libraries... > Install the Minim library)

2. Run the "group_5_assignment4.pde" file to begin the animation.

3. If desired, the following arguments can be changed to affect the animation:

Birds - In order of left to right, the arguments include floats for the x position, y position, bird speed, wing speed, x direction and y direction. Note that a positive x direction corresponds to moving to the right, negative x corresponds to the left, positive y direction corresponds to moving downwards, and negative y corresponds to moving upwards.

Campfires - In order of left to right, the arguments include floats for the x position, y position, flame offset x and y position, flicker speed, and color for the flame.

Field - In order of left to right, the arguments include the a float for the field's height on screen, a color for its base, the x and y position of the campfire, and a float for the density of grass in the field.