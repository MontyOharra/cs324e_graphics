Open the .pde file and click 'Run' to display the image.
